package payment_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentServiecApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentServiecApplication.class, args);
	}

}
